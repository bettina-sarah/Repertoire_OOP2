package com.example.appexfinalmerveilles;

public class Merveille {

    private String nom;
    private String categorie ; // ancienne ou moderne
    private boolean encoreExistante;

    public Merveille(String nom, String categorie, boolean encoreExistante) {
        this.nom = nom;
        this.categorie = categorie;
        this.encoreExistante = encoreExistante;
    }

    public String getNom() {
        return nom;
    }

    public String getCategorie() {
        return categorie;
    }

    public boolean isEncoreExistante() {
        return encoreExistante;
    }
}
