package com.example.appexfinalmerveilles;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class MenuActivity extends AppCompatActivity {

    Button quizCategorie;
    Button quizExistance;

    Ecouteur ec;

    Intent i;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        quizCategorie = findViewById(R.id.boutonCategorie);
        quizExistance = findViewById(R.id.boutonExistant);//pas necessaire

        ec = new Ecouteur();
        quizCategorie.setOnClickListener(ec);
        quizExistance.setOnClickListener(ec); //pas necessaire

        i = new Intent(MenuActivity.this, QuizActivity.class);

    }

    private class Ecouteur implements View.OnClickListener {

        @Override
        public void onClick(View source) {
            if(source == quizCategorie){
                startActivity(i);
                finish();
            }
            //2eme bouton pas necessaire
        }
    }

}