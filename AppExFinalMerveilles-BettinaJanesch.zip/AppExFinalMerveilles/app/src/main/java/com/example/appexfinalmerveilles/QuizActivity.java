package com.example.appexfinalmerveilles;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.DragEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Vector;

public class QuizActivity extends AppCompatActivity {

    LinearLayout choixDepart;
    LinearLayout moderne;
    LinearLayout antique;
    Button boutonCorrection;
    TextView textCorrection;

    Ecouteur ec;
    DBHelper instance;

    Vector<String> vectMerveilles;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        choixDepart = findViewById(R.id.choixDepart);
        moderne = findViewById(R.id.moderne);
        antique = findViewById(R.id.antique);
        boutonCorrection = findViewById(R.id.boutonCorrection);
        textCorrection = findViewById(R.id.textCorrection);
        ec = new Ecouteur();

        instance = DBHelper.getInstance(getApplicationContext());
        instance.ouvrirBD();
        vectMerveilles = instance.GetMerveilles();

        //ondrag listener pour les linear layout
        choixDepart.setOnDragListener(ec);
        moderne.setOnDragListener(ec);
        antique.setOnDragListener(ec);
        boutonCorrection.setOnClickListener(ec);

        // injecter noms merveilles dans TextView + on touch listener

        for (int i = 0; i < choixDepart.getChildCount(); i++) {
            TextView temp = ((TextView) choixDepart.getChildAt(i));
            temp.setText(vectMerveilles.elementAt(i));
            temp.setOnTouchListener(ec);
        }

    }

    private class Ecouteur implements View.OnDragListener, View.OnTouchListener, View.OnClickListener {

        View merveille = null;

        @Override
        public boolean onDrag(View source, DragEvent event) {

            switch (event.getAction()) { // if event.getAction() == DragEvent.ACTION_DRAG_STARTED
                case DragEvent.ACTION_DROP:
                    //source/objet de startDragAndDrop de touchlistener (param de ca on recupere ici)
                    merveille = (View) event.getLocalState(); //retourne textView draggé
                    //get colonne d'origine
                    LinearLayout parentOrigine = (LinearLayout) merveille.getParent();
                    //enleve textView de la LL parent
                    parentOrigine.removeView(merveille);
                    //source = nouvelle LL
                    LinearLayout nouveauParent = (LinearLayout) source;
                    nouveauParent.addView(merveille);
                    merveille.setVisibility(View.VISIBLE);
                    break;

                case DragEvent.ACTION_DRAG_ENDED:
                    merveille = (View) event.getLocalState();
                    merveille.setVisibility(View.VISIBLE);
                    break;
            }
            return true;
        }

        @Override
        public boolean onTouch(View source, MotionEvent event) {
            //faire shadowbuilder, assigner au textview et rendre txtview invisible
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(source);

            source.startDragAndDrop(null, shadow, source, 0);

            source.setVisibility(View.INVISIBLE);

            return true;
        }

        @Override
        public void onClick(View source) {
            if (source == boutonCorrection) {
                validerChoix();
            }

        }
    }

    public void validerChoix() {
        Vector<Boolean> reponses = new Vector<>();

        // 1. parcourir les 2 LL pour recuperer valeurs des TextView
        // 2. mettre dans vect de boolean en fonc des reponses

        for (int i = 0; i < antique.getChildCount(); i++) {
            if (antique.getChildAt(i) instanceof TextView) {
                TextView tempView = ((TextView) antique.getChildAt(i));
                boolean resultatTemp = instance.EstModerne(tempView.getText().toString());
                //si methode renvoye false, c'est bon, c'est antique
                if (!resultatTemp) {
                    reponses.add(true);
                } else {
                    reponses.add(resultatTemp);
                }
            }
        }

        for (int i = 0; i < moderne.getChildCount(); i++) {
            if (moderne.getChildAt(i) instanceof TextView) {
                TextView tempView = ((TextView) moderne.getChildAt(i));
                boolean resultatTemp = instance.EstModerne(tempView.getText().toString());
                reponses.add(resultatTemp);
            }
        }

        //on parcours le vecteur de bool pour avoir le texte de correction:
        int score = 5;
        for (int i = 0; i < reponses.size(); i++) {
            if (!reponses.elementAt(i)) {
                    //si pas bonne reponse, baisse score:
                    score--;
                }
            }
        String stringScore = Integer.toString(score);
        String reponsePartiale = stringScore + "/5 ...continuez";
        String reponseParfaite = "5/5... BRAVOOO";
        if (score == 5) {
            textCorrection.setText(reponseParfaite);
        } else {
            textCorrection.setText(reponsePartiale);
        }
    }

}