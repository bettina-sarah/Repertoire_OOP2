package com.example.appexfinalmerveilles;


import android.content.ContentValues;
import android.content.Context;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.Vector;


public class DBHelper extends SQLiteOpenHelper {

    private static DBHelper instance;

    private SQLiteDatabase conn;

    public static DBHelper getInstance(Context contexte){
        if(instance == null){
            instance = new DBHelper(contexte);
        }

        return instance;

    }

    private DBHelper(Context contexte) {
        super(contexte, "merveilles", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table Merveille ( _id INTEGER PRIMARY KEY AUTOINCREMENT, NOM TEXT, CATEGORIE TEXT, EXISTE INTEGER);");
        ajouterMerveille( new Merveille("Pyramide de Khéops", "antique", true), db); /* type boolean n'existe pas ds sqlite mais true =1 et false = 0*/
        ajouterMerveille( new Merveille("Phare Alexandrie", "antique", false), db);
        ajouterMerveille( new Merveille("Taj Mahal", "moderne", true), db);
        ajouterMerveille( new Merveille("Macchu Pichu", "moderne", true), db);
        ajouterMerveille( new Merveille("Colisée de Rome", "moderne", true), db);
    }

    public void ajouterMerveille ( Merveille m,SQLiteDatabase db )
    {
        ContentValues cv = new ContentValues();
        cv.put("NOM", m.getNom());
        cv.put("CATEGORIE", m.getCategorie());
        cv.put("EXISTE", m.isEncoreExistante());

        db.insert("Merveille", null, cv);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("drop table if exists Merveille;");
        onCreate(db);

    }

    public void ouvrirBD(){
        conn = this.getWritableDatabase();
    }

    public void fermerBD(){
        conn.close();
    }

    public boolean EstModerne(String aVerifier){// antique ou moderne
        String[] tab = {aVerifier, "moderne"};
        Cursor c = conn.rawQuery("select NOM FROM Merveille WHERE NOM = ? AND CATEGORIE = ?", tab);
        boolean resultat = c.moveToFirst();
        c.close();
        return resultat; //si trouvé, true, sinon, false
    }

    public boolean EstExistante(String aVerifier){
        String[] tab = {aVerifier}; //EXISTE
        Cursor c = conn.rawQuery("select EXISTE FROM Merveille WHERE NOM = ?", tab);
        c.moveToFirst();
        String resultat = c.getString(0); //true =1 et false = 0*/0
        c.close();
        if(resultat.equals("1")){
            return true;
        }
            return false;
    }


    public Vector<String> GetMerveilles(){
        Vector<String> vect = new Vector<>();
        Cursor c = conn.rawQuery("select NOM FROM Merveille", null);
        while(c.moveToNext()){
            vect.add(c.getString(0));
        }
        c.close();
        return vect;
    }





}
